using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        var cursos = new List<Curso>
        {
            new Curso { Id = 1, Titulo = "Desenvolvimento Web Full Stack", Descricao = "Aprenda a criar aplicações web modernas utilizando HTML, CSS, JavaScript, Node.js e muito mais.", CargaHoraria = 80, Concluido = false },
            new Curso { Id = 2, Titulo = "Introdução à Fotografia Digital", Descricao = "Explore os fundamentos da fotografia e aprenda a tirar fotos incríveis com sua câmera ou smartphone.", CargaHoraria = 25, Concluido = true },
            new Curso { Id = 3, Titulo = "Gestão de Projetos Ágeis", Descricao = "Curso voltado à aplicação de metodologias ágeis como Scrum e Kanban em ambientes corporativos.", CargaHoraria = 40, Concluido = true },
            new Curso { Id = 4, Titulo = "Design Gráfico com Canva", Descricao = "Crie materiais visuais impactantes para redes sociais, empresas ou uso pessoal usando o Canva.", CargaHoraria = 15, Concluido = true }
        };

        return View(cursos);
    }
}