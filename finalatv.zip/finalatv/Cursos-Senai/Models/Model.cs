#pragma warning disable CA1050 // Declare types in namespaces
public class Curso
#pragma warning restore CA1050 // Declare types in namespaces
{
    public int Id { get; set; }
    public required string Titulo { get; set; }
    public required string Descricao { get; set; }
    public int CargaHoraria { get; set; }
    public bool Concluido { get; set; }
}