﻿document.addEventListener("DOMContentLoaded", () => {

    const inscreverBtns = document.querySelectorAll(".inscrever");
    
    inscreverBtns.forEach(btn => {
        btn.addEventListener("click", function() {
            const card = this.closest(".curso-card");
            const titulo = card.querySelector(".section-title").textContent;
            
            this.textContent = "INSCRITO";
            this.disabled = true;
            this.style.opacity = "0.7";
            
            alert(`Inscrição no curso "${titulo}" realizada com sucesso!`);
        });
    });
    
  
    const saibaMaisBtns = document.querySelectorAll(".saiba-mais");
    
    saibaMaisBtns.forEach(btn => {
        btn.addEventListener("click", function() {
            const card = this.closest(".curso-card");
            const titulo = card.querySelector(".section-title").textContent;
            const descricao = card.querySelector(".curso-content p").textContent;
            
            alert(`Curso: ${titulo}\n\nDescrição: ${descricao}`);
        });
    });
});